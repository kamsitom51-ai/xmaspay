# XMAS EARN — starter MVP

This is a runnable Node.js + SQLite starter for the XMAS EARN concept. It includes member registration/login, manual bank-transfer proof submissions, admin deposit approval, membership plans, referral commissions, tasks and proof review, creator campaign submissions, bank-account binding, withdrawal requests, announcements, daily sign-in, and a disabled-by-default cash slot feature.

## Run locally

1. Install Node.js 20 or newer.
2. Extract this folder.
3. In this folder, run `npm install`.
4. Copy `.env.example` to `.env` and set a long random `SESSION_SECRET`, `ADMIN_EMAIL`, and a strong `ADMIN_PASSWORD`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

The first admin account is created from the environment variables when the database is first initialized. Keep `.env` private. Do not upload it to a public repository.

## Important configuration

- The displayed bank details are the details supplied for the project. Verify the account and transfer capability directly with the account provider before accepting payments.
- Membership activates only after an admin approves a payment-proof submission. Admin must verify funds in the actual account; an uploaded image is not proof that money arrived.
- Referral commissions are recorded only when a referred member's paid membership is approved. Budget commissions, tasks, refunds, fees and operating costs from genuine revenue before accepting payments.
- Creator campaigns are submitted for review. This starter does not collect campaign funding or automatically publish social tasks; add a verified funding workflow before activating campaigns.
- Daily sign-in currently records attendance only; no cash reward is configured.
- Cash slot prizes are disabled by default. Do not enable them until Nigerian legal review, required approvals and a funded prize reserve are in place. Free entry does not automatically make a cash-prize chance game exempt from gambling/lottery rules.
- Social platform policies may prohibit incentivized likes, follows, subscriptions or other engagement. Only allow campaign tasks permitted by the relevant platform.

## Before public launch — required hardening

This is an MVP starter, not a production-certified financial platform. Before real users or money:
- Deploy behind HTTPS.
- Replace Express's default in-memory session store with a persistent production session store.
- Add CSRF protection, email/phone verification, password reset, stronger rate limits and audit logs.
- Restrict uploads to private storage and serve proof images only to authorized admins. Add malware scanning and validate actual file contents, not only MIME headers.
- Add an atomic withdrawal reservation/ledger workflow, idempotency, reconciliation, dispute/refund handling and daily accounting reports. Admin should verify bank transfers and mark withdrawals paid only after executing them.
- Add campaign funding escrow, campaign delivery verification, creator identity checks and refunds.
- Add privacy policy, terms, retention rules and Nigerian legal/accounting review.
- Set a funded reward budget. Do not imply that membership deposits are investments or promise guaranteed earnings.
- Back up the SQLite database or migrate to managed PostgreSQL before scaling.

## Existing design details
Pink/gold professional theme; Pampay bank transfer details and WhatsApp support number are shown in the app configuration endpoint. Change them in `server.js` before launch if needed.
