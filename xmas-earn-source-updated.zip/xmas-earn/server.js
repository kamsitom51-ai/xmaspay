const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET = process.env.SESSION_SECRET || "development-only-change-me";
const DB = new Database("xmas-earn.sqlite");
const CASH_SLOT_PRIZES_ENABLED = process.env.CASH_SLOT_PRIZES_ENABLED === "true";

if (SECRET === "development-only-change-me" && process.env.NODE_ENV === "production") {
  throw new Error("Set a strong SESSION_SECRET before production.");
}

DB.pragma("journal_mode = WAL");
DB.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, username TEXT UNIQUE NOT NULL,
 email TEXT UNIQUE NOT NULL, phone TEXT NOT NULL, password_hash TEXT NOT NULL,
 referral_code TEXT UNIQUE NOT NULL, referred_by INTEGER, role TEXT NOT NULL DEFAULT 'member',
 plan TEXT, membership_status TEXT NOT NULL DEFAULT 'inactive',
 bank_name TEXT, bank_account_name TEXT, bank_account_number TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS deposits (
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, plan TEXT NOT NULL,
 amount INTEGER NOT NULL, proof_path TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 reviewed_by INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ledger (
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, amount INTEGER NOT NULL,
 kind TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'approved',
 note TEXT, related_user_id INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tasks (
 id INTEGER PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL,
 reward INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS submissions (
 id INTEGER PRIMARY KEY, task_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 proof TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS campaigns (
 id INTEGER PRIMARY KEY, creator_id INTEGER NOT NULL, title TEXT NOT NULL,
 platform TEXT NOT NULL, url TEXT NOT NULL, instructions TEXT NOT NULL,
 participants INTEGER NOT NULL, budget INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS withdrawals (
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, amount INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS announcements (
 id INTEGER PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS signins (
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, day TEXT NOT NULL,
 UNIQUE(user_id, day)
);
CREATE TABLE IF NOT EXISTS spins (
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 prize INTEGER NOT NULL DEFAULT 50, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const plans = {
  Starter: { price: 1000, commission: 400, tasks: 3 },
  Standard: { price: 2500, commission: 1000, tasks: 5 },
  Premium: { price: 5000, commission: 2000, tasks: 10 }
};

const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase())
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = ["image/jpeg", "image/png", "application/pdf"].includes(file.mimetype);
    cb(ok ? null : new Error("Upload JPG, PNG or PDF only."), ok);
  }
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: "xmas.sid", secret: SECRET, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 *  60 * 60 * 1000 }
}));
app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 250 }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(uploadDir, { dotfiles: "deny", index: false }));

function user(req) { return req.session.user || null; }
function requireAuth(req, res, next) {
  if (!user(req)) return res.status(401).json({ error: "Please log in first." });
  next();
}
function requireAdmin(req, res, next) {
  if (!user(req) || user(req).role !== "admin") return res.status(403).json({ error: "Admin access required." });
  next();
}
function balance(userId) {
  return DB.prepare("SELECT COALESCE(SUM(amount),0) AS total FROM ledger WHERE user_id=? AND status='approved'").get(userId).total;
}
function publicUser(u) {
  return { id:u.id, name:u.name, username:u.username, email:u.email, phone:u.phone,
    role:u.role, plan:u.plan, membership_status:u.membership_status, referral_code:u.referral_code,
    balance: balance(u.id), bank_name:u.bank_name, bank_account_name:u.bank_account_name,
    bank_account_number:u.bank_account_number };
}
function makeCode() { return crypto.randomBytes(4).toString("hex").toUpperCase(); }

// Seed admin from environment. Never put admin credentials in browser code.
const adminEmail = process.env.ADMIN_EMAIL;
const adminPassword = process.env.ADMIN_PASSWORD;
if (adminEmail && adminPassword && !DB.prepare("SELECT id FROM users WHERE email=?").get(adminEmail)) {
  const hash = bcrypt.hashSync(adminPassword, 12);
  DB.prepare(`INSERT INTO users(name,username,email,phone,password_hash,referral_code,role,membership_status)
    VALUES(?,?,?,?,?,?,?,?)`).run("XMAS EARN Admin","admin",adminEmail,"",hash,makeCode(),"admin","active");
}

app.get("/api/config", (_req,res) => res.json({
  plans, bank: { name:"Pampay", accountNumber:"9068543647", accountName:"Ishmael Esther Chidinma" },
  whatsapp:"+2349068543647", cashSlotPrizesEnabled:CASH_SLOT_PRIZES_ENABLED
}));

app.post("/api/register", async (req,res) => {
  const {name,username,email,phone,password,referralCode} = req.body;
  if (!name || !username || !email || !phone || !password || password.length < 10)
    return res.status(400).json({error:"Complete all fields. Password must be at least 10 characters."});
  const existing = DB.prepare("SELECT id FROM users WHERE email=? OR username=?").get(email.toLowerCase(),username);
  if (existing) return res.status(409).json({error:"Email or username already exists."});
  const ref = referralCode ? DB.prepare("SELECT id FROM users WHERE referral_code=? AND membership_status='active'").get(referralCode) : null;
  const hash = await bcrypt.hash(password, 12);
  const code = makeCode();
  try {
    const info = DB.prepare(`INSERT INTO users(name,username,email,phone,password_hash,referral_code,referred_by)
      VALUES(?,?,?,?,?,?,?)`).run(name,username,email.toLowerCase(),phone,hash,code,ref?.id || null);
    req.session.user = {id:Number(info.lastInsertRowid), role:"member"};
    res.json({ok:true});
  } catch { res.status(400).json({error:"Could not create account. Check your details."}); }
});

app.post("/api/login", async (req,res) => {
  const u = DB.prepare("SELECT * FROM users WHERE email=?").get(String(req.body.email||"").toLowerCase());
  if (!u || !(await bcrypt.compare(req.body.password||"",u.password_hash)))
    return res.status(401).json({error:"Incorrect email or password."});
  req.session.regenerate(err => {
    if (err) return res.status(500).json({error:"Could not start session."});
    req.session.user = {id:u.id,role:u.role};
    res.json({ok:true});
  });
});
app.post("/api/logout", (req,res) => req.session.destroy(() => res.json({ok:true})));
app.get("/api/me", requireAuth, (req,res) => {
  const u = DB.prepare("SELECT * FROM users WHERE id=?").get(user(req).id);
  res.json({user:publicUser(u), plans});
});

app.post("/api/deposits", requireAuth, upload.single("proof"), (req,res) => {
  const plan = plans[req.body.plan];
  if (!plan || !req.file) return res.status(400).json({error:"Choose a plan and upload payment proof."});
  const info = DB.prepare("INSERT INTO deposits(user_id,plan,amount,proof_path) VALUES(?,?,?,?)")
    .run(user(req).id,req.body.plan,plan.price,req.file.filename);
  res.json({ok:true,id:info.lastInsertRowid,message:"Payment proof submitted. Membership stays pending until bank receipt is verified."});
});

app.get("/api/deposits", requireAuth, (req,res) => {
  const rows = user(req).role==="admin"
    ? DB.prepare(`SELECT d.*,u.username FROM deposits d JOIN users u ON u.id=d.user_id ORDER BY d.id DESC`).all()
    : DB.prepare("SELECT * FROM deposits WHERE user_id=? ORDER BY id DESC").all(user(req).id);
  res.json(rows);
});
app.post("/api/admin/deposits/:id/approve", requireAdmin, (req,res) => {
  const d = DB.prepare("SELECT * FROM deposits WHERE id=? AND status='pending'").get(req.params.id);
  if (!d) return res.status(404).json({error:"Pending deposit not found."});
  const plan = plans[d.plan];
  const tx = DB.transaction(() => {
    DB.prepare("UPDATE deposits SET status='approved',reviewed_by=? WHERE id=?").run(user(req).id,d.id);
    DB.prepare("UPDATE users SET plan=?,membership_status='active' WHERE id=?").run(d.plan,d.user_id);
    const referred = DB.prepare("SELECT referred_by FROM users WHERE id=?").get(d.user_id);
    if (referred?.referred_by) {
      DB.prepare("INSERT INTO ledger(user_id,amount,kind,note,related_user_id) VALUES(?,?,?,?,?)")
        .run(referred.referred_by,plan.commission,"referral",`Referral commission for ${d.plan} membership`,d.user_id);
    }
  });
  tx(); res.json({ok:true});
});
app.post("/api/admin/deposits/:id/reject", requireAdmin, (req,res) => {
  const info = DB.prepare("UPDATE deposits SET status='rejected',reviewed_by=? WHERE id=? AND status='pending'").run(user(req).id,req.params.id);
  res.json({ok:info.changes>0});
});

app.get("/api/tasks", requireAuth, (req,res) => {
  const u = DB.prepare("SELECT * FROM users WHERE id=?").get(user(req).id);
  if (u.membership_status!=="active") return res.json([]);
  const limit = plans[u.plan]?.tasks || 0;
  res.json(DB.prepare("SELECT * FROM tasks WHERE active=1 ORDER BY id DESC LIMIT ?").all(limit));
});
app.post("/api/tasks/:id/submit", requireAuth, (req,res) => {
  const {proof} = req.body;
  if (!proof || proof.length > 1000) return res.status(400).json({error:"Enter a proof link or short description."});
  const task = DB.prepare("SELECT id FROM tasks WHERE id=? AND active=1").get(req.params.id);
  if (!task) return res.status(404).json({error:"Task unavailable."});
  const exists = DB.prepare("SELECT id FROM submissions WHERE task_id=? AND user_id=?").get(task.id,user(req).id);
  if (exists) return res.status(409).json({error:"You already submitted this task."});
  DB.prepare("INSERT INTO submissions(task_id,user_id,proof) VALUES(?,?,?)").run(task.id,user(req).id,proof);
  res.json({ok:true});
});
app.get("/api/admin/submissions", requireAdmin, (_req,res) => res.json(
  DB.prepare(`SELECT s.*,t.title,t.reward,u.username FROM submissions s JOIN tasks t ON t.id=s.task_id JOIN users u ON u.id=s.user_id ORDER BY s.id DESC`).all()
));
app.post("/api/admin/submissions/:id/approve", requireAdmin, (req,res) => {
  const s = DB.prepare("SELECT * FROM submissions WHERE id=? AND status='pending'").get(req.params.id);
  if (!s) return res.status(404).json({error:"Pending submission not found."});
  const t = DB.prepare("SELECT * FROM tasks WHERE id=?").get(s.task_id);
  const tx = DB.transaction(() => {
    DB.prepare("UPDATE submissions SET status='approved' WHERE id=?").run(s.id);
    DB.prepare("INSERT INTO ledger(user_id,amount,kind,note) VALUES(?,?,?,?)").run(s.user_id,t.reward,"task",`Approved task: ${t.title}`);
  });
  tx(); res.json({ok:true});
});
app.post("/api/admin/tasks", requireAdmin, (req,res) => {
  const {title,description,reward} = req.body;
  if (!title || !description || !Number.isInteger(Number(reward)) || Number(reward)<1)
    return res.status(400).json({error:"Provide title, description and a positive whole-naira reward."});
  const info = DB.prepare("INSERT INTO tasks(title,description,reward) VALUES(?,?,?)").run(title,description,Number(reward));
  res.json({ok:true,id:info.lastInsertRowid});
});

app.post("/api/signin", requireAuth, (req,res) => {
  const today = new Date().toISOString().slice(0,10);
  try {
    DB.prepare("INSERT INTO signins(user_id,day) VALUES(?,?)").run(user(req).id,today);
    res.json({ok:true,message:"Daily sign-in recorded. No cash reward is configured yet."});
  } catch { res.status(409).json({error:"You have already signed in today."}); }
});
app.get("/api/referrals", requireAuth, (req,res) => {
  const u = DB.prepare("SELECT referral_code FROM users WHERE id=?").get(user(req).id);
  const people = DB.prepare("SELECT username,created_at,membership_status,plan FROM users WHERE referred_by=? ORDER BY id DESC").all(user(req).id);
  const earnings = DB.prepare("SELECT COALESCE(SUM(amount),0) total FROM ledger WHERE user_id=? AND kind='referral' AND status='approved'").get(user(req).id).total;
  res.json({code:u.referral_code,people,earnings});
});

app.post("/api/bank-account", requireAuth, (req,res) => {
  const {bankName,accountName,accountNumber} = req.body;
  if (!bankName || !accountName || !/^[0-9]{10}$/.test(accountNumber||""))
    return res.status(400).json({error:"Enter bank, account name and a 10-digit account number."});
  DB.prepare("UPDATE users SET bank_name=?,bank_account_name=?,bank_account_number=? WHERE id=?")
    .run(bankName,accountName,accountNumber,user(req).id);
  res.json({ok:true});
});
app.post("/api/withdrawals", requireAuth, (req,res) => {
  const amount = Number(req.body.amount);
  const u = DB.prepare("SELECT * FROM users WHERE id=?").get(user(req).id);
  if (u.membership_status!=="active") return res.status(403).json({error:"An active membership is required."});
  if (!u.bank_account_number) return res.status(400).json({error:"Bind a bank account first."});
  if (!Number.isInteger(amount) || amount<500) return res.status(400).json({error:"Minimum withdrawal is ₦500."});
  const pending = DB.prepare("SELECT COALESCE(SUM(amount),0) total FROM withdrawals WHERE user_id=? AND status IN ('pending','approved')").get(u.id).total;
  if (balance(u.id)-pending < amount) return res.status(400).json({error:"Insufficient available balance."});
  DB.prepare("INSERT INTO withdrawals(user_id,amount) VALUES(?,?)").run(u.id,amount);
  res.json({ok:true});
});
app.get("/api/withdrawals", requireAuth, (req,res) => res.json(
  user(req).role==="admin"
   ? DB.prepare("SELECT w.*,u.username,u.bank_name,u.bank_account_name,u.bank_account_number FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.id DESC").all()
   : DB.prepare("SELECT * FROM withdrawals WHERE user_id=? ORDER BY id DESC").all(user(req).id)
));
app.post("/api/admin/withdrawals/:id/:action", requireAdmin, (req,res) => {
  const action=req.params.action;
  if (!["approve","reject","paid"].includes(action)) return res.status(400).json({error:"Invalid action."});
  const status=action==="approve"?"approved":action==="paid"?"paid":"rejected";
  const w=DB.prepare("SELECT * FROM withdrawals WHERE id=? AND status='pending'").get(req.params.id);
  if (!w) return res.status(404).json({error:"Pending withdrawal not found."});
  const tx=DB.transaction(()=>{
    DB.prepare("UPDATE withdrawals SET status=? WHERE id=?").run(status,w.id);
    if (status==="paid") DB.prepare("INSERT INTO ledger(user_id,amount,kind,note) VALUES(?,?,?,?)")
      .run(w.user_id,-w.amount,"withdrawal",`Withdrawal #${w.id} paid`);
  });
  tx(); res.json({ok:true});
});

app.post("/api/campaigns", requireAuth, (req,res) => {
  const {title,platform,url,instructions,participants,budget}=req.body;
  if (!title||!platform||!/^https?:\/\//i.test(url||"")||!instructions||Number(participants)<1||Number(budget)<1)
    return res.status(400).json({error:"Complete all campaign fields with a valid URL, participant count and budget."});
  const info=DB.prepare("INSERT INTO campaigns(creator_id,title,platform,url,instructions,participants,budget) VALUES(?,?,?,?,?,?,?)")
    .run(user(req).id,title,platform,url,instructions,Number(participants),Number(budget));
  res.json({ok:true,id:info.lastInsertRowid,message:"Campaign submitted for admin review. Funding and campaign activation must be verified before tasks go live."});
});
app.get("/api/campaigns", requireAuth, (req,res)=>res.json(
  user(req).role==="admin"
    ? DB.prepare("SELECT c.*,u.username FROM campaigns c JOIN users u ON u.id=c.creator_id ORDER BY c.id DESC").all()
    : DB.prepare("SELECT * FROM campaigns WHERE creator_id=? ORDER BY id DESC").all(user(req).id)
));
app.post("/api/admin/announcements", requireAdmin, (req,res)=>{
  if(!req.body.title||!req.body.body) return res.status(400).json({error:"Title and message required."});
  DB.prepare("INSERT INTO announcements(title,body) VALUES(?,?)").run(req.body.title,req.body.body);
  res.json({ok:true});
});
app.get("/api/announcements", requireAuth, (_req,res)=>res.json(DB.prepare("SELECT * FROM announcements ORDER BY id DESC").all()));

app.post("/api/slot/spin", requireAuth, (req,res)=>{
  if(!CASH_SLOT_PRIZES_ENABLED) return res.status(403).json({error:"Cash-prize slot is disabled pending legal clearance and prize funding."});
  const u=DB.prepare("SELECT membership_status FROM users WHERE id=?").get(user(req).id);
  if(u.membership_status!=="active") return res.status(403).json({error:"Active membership required."});
  const referrals=DB.prepare("SELECT COUNT(*) n FROM users WHERE referred_by=? AND membership_status='active'").get(user(req).id).n;
  const used=DB.prepare("SELECT COUNT(*) n FROM spins WHERE user_id=?").get(user(req).id).n;
  if(referrals<=used) return res.status(400).json({error:"You need an unused successful referral spin."});
  const win=Math.random()<0.1;
  DB.prepare("INSERT INTO spins(user_id,status,prize) VALUES(?,?,?)").run(user(req).id,win?"pending":"no_win",50);
  res.json({ok:true,result:win?"win_pending":"no_win",message:win?"₦50 win pending admin approval.":"No win this time."});
});
app.get("/api/admin/spins", requireAdmin, (_req,res)=>res.json(
  DB.prepare("SELECT s.*,u.username FROM spins s JOIN users u ON u.id=s.user_id WHERE s.status='pending' ORDER BY s.id DESC").all()
));
app.post("/api/admin/spins/:id/approve", requireAdmin, (req,res)=>{
  const s=DB.prepare("SELECT * FROM spins WHERE id=? AND status='pending'").get(req.params.id);
  if(!s) return res.status(404).json({error:"Pending win not found."});
  const tx=DB.transaction(()=>{
    DB.prepare("UPDATE spins SET status='approved' WHERE id=?").run(s.id);
    DB.prepare("INSERT INTO ledger(user_id,amount,kind,note) VALUES(?,?,?,?)").run(s.user_id,50,"slot_win","Approved slot-game prize");
  });
  tx();res.json({ok:true});
});

app.get("/api/admin/summary", requireAdmin, (_req,res)=>res.json({
 users:DB.prepare("SELECT COUNT(*) n FROM users WHERE role='member'").get().n,
 pendingDeposits:DB.prepare("SELECT COUNT(*) n FROM deposits WHERE status='pending'").get().n,
 pendingTasks:DB.prepare("SELECT COUNT(*) n FROM submissions WHERE status='pending'").get().n,
 pendingWithdrawals:DB.prepare("SELECT COUNT(*) n FROM withdrawals WHERE status='pending'").get().n
}));

app.use((err,_req,res,_next)=>{
  console.error(err);
  res.status(400).json({error:err.message||"Request failed."});
});
app.listen(PORT,()=>console.log(`XMAS EARN running on http://localhost:${PORT}`));
